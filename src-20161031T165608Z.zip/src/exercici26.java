
public class exercici26 {

}
