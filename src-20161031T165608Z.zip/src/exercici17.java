import java.util.Scanner;
public class exercici17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int x;
		double mesde20;
		double menysde20;
		//Definim Entrada del tipus Scanner per poder llegir
		Scanner entrada;
		//Iniciem les variables
		entrada = new Scanner(System.in);
		x=0;
		mesde20=0;
		menysde20=0;
		//Bloc de codi principal
		System.out.println("Entra el numero:");
		x=entrada.nextInt();
		if(x>20)
			{ 	mesde20= Math.pow(x, 2);
				System.out.println(""+ mesde20);
			}
		else
			{ 	menysde20= Math.pow(x, 3);
			System.out.println(""+ menysde20);
			}
	}
}

